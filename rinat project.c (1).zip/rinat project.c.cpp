#include <stdio.h>


void addPoints(int *score) {
    int point;
    printf("Kazanilan puani giriniz: ");
    scanf("%d", &point);
    *score += point;
}


void showWinner(char w1[], char w2[], int s1, int s2) {
    printf("\n--- MAC SONUCU ---\n");
    if (s1 > s2)
        printf("Kazanan: %s \n", w1);
    else if (s2 > s1)
        printf("Kazanan: %s \n", w2);
    else
        printf("Mac Berabere \n");
}

int main() {
    char wrestler1[30], wrestler2[30];
    int score1 = 0, score2 = 0;
    int choice;

    printf("1. Gurescinin adini giriniz: ");
    scanf("%s", wrestler1);
    printf("2. Gurescinin adini giriniz: ");
    scanf("%s", wrestler2);

    while (1) {
        printf("\n--- MENU ---\n");
        printf("1. %s icin puan ekle\n", wrestler1);
        printf("2. %s icin puan ekle\n", wrestler2);
        printf("3. Skoru goster\n");
        printf("4. Kazanani goster\n");
        printf("5. Cikis\n");
        printf("Seciminiz: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addPoints(&score1);
                break;
            case 2:
                addPoints(&score2);
                break;
            case 3:
                printf("Skor: %s = %d | %s = %d\n",
                       wrestler1, score1, wrestler2, score2);
                break;
            case 4:
                showWinner(wrestler1, wrestler2, score1, score2);
                break;
            case 5:
                printf("Programdan cikiliyor...\n");
                return 0;
            default:
                printf("Gecersiz secim!\n");
        }
    }
}